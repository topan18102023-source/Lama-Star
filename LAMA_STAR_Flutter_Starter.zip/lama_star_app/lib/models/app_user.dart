class AppUser {
  const AppUser({
    required this.id,
    required this.name,
    this.email = '',
    this.coins = 1200,
    this.diamonds = 50,
    this.role = 'member',
  });

  final String id;
  final String name;
  final String email;
  final int coins;
  final int diamonds;
  final String role;

  factory AppUser.demo() => const AppUser(
        id: 'demo-user-001',
        name: 'Bintang LAMA',
        email: 'demo@lamastar.app',
        role: 'host',
      );
}
