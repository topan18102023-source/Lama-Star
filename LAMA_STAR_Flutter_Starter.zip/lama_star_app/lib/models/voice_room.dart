class VoiceRoom {
  const VoiceRoom({
    required this.id,
    required this.title,
    required this.topic,
    required this.memberCount,
    required this.isPrivate,
    required this.ownerId,
    this.coverEmoji = '🎙️',
  });

  final String id;
  final String title;
  final String topic;
  final int memberCount;
  final bool isPrivate;
  final String ownerId;
  final String coverEmoji;

  factory VoiceRoom.fromMap(String id, Map<String, dynamic> data) {
    return VoiceRoom(
      id: id,
      title: data['title'] as String? ?? 'Room LAMA STAR',
      topic: data['topic'] as String? ?? 'Tempat ngobrol bersama',
      memberCount: (data['memberCount'] as num?)?.toInt() ?? 0,
      isPrivate: data['isPrivate'] as bool? ?? false,
      ownerId: data['ownerId'] as String? ?? '',
      coverEmoji: data['coverEmoji'] as String? ?? '🎙️',
    );
  }

  Map<String, dynamic> toMap() => {
        'title': title,
        'topic': topic,
        'memberCount': memberCount,
        'isPrivate': isPrivate,
        'ownerId': ownerId,
        'coverEmoji': coverEmoji,
      };

  static List<VoiceRoom> demoRooms = const [
    VoiceRoom(
      id: 'demo-room-1',
      title: 'LAMA STAR Lounge',
      topic: 'Ngobrol santai dan cari teman baru',
      memberCount: 28,
      isPrivate: false,
      ownerId: 'demo-user-001',
      coverEmoji: '🌟',
    ),
    VoiceRoom(
      id: 'demo-room-2',
      title: 'Room Musik Indonesia',
      topic: 'Request lagu dan karaoke bersama',
      memberCount: 16,
      isPrivate: false,
      ownerId: 'demo-host-2',
      coverEmoji: '🎵',
    ),
    VoiceRoom(
      id: 'demo-room-3',
      title: 'Teman Malam',
      topic: 'Cerita, diskusi, dan hiburan',
      memberCount: 9,
      isPrivate: true,
      ownerId: 'demo-host-3',
      coverEmoji: '🌙',
    ),
  ];
}
