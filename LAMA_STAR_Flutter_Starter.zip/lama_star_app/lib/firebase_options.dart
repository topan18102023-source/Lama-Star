// File placeholder. Jalankan `flutterfire configure` untuk menggantinya
// dengan konfigurasi resmi proyek Firebase Anda.
import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    throw UnsupportedError(
      'Konfigurasi Firebase belum dibuat. Jalankan perintah: flutterfire configure',
    );
  }
}
