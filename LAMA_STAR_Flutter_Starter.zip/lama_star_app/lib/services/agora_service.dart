import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:permission_handler/permission_handler.dart';

import '../config/app_config.dart';

class AgoraService {
  RtcEngine? _engine;
  bool _joined = false;
  bool _muted = false;

  bool get isJoined => _joined;
  bool get isMuted => _muted;

  Future<void> join({
    required String roomId,
    required void Function(int uid) onUserJoined,
    required void Function(int uid) onUserLeft,
    required void Function(String message) onError,
  }) async {
    if (!AppConfig.useFirebase) return;

    final permission = await Permission.microphone.request();
    if (!permission.isGranted) {
      throw StateError('Izin mikrofon diperlukan untuk masuk ke voice room.');
    }

    final callable = FirebaseFunctions.instanceFor(
      region: AppConfig.functionsRegion,
    ).httpsCallable('getAgoraRtcToken');
    final response = await callable.call({'roomId': roomId});
    final data = Map<String, dynamic>.from(response.data as Map);
    final appId = data['appId'] as String? ?? '';
    final token = data['token'] as String? ?? '';
    final uid = (data['uid'] as num?)?.toInt() ?? 0;

    if (appId.isEmpty || token.isEmpty || uid <= 0) {
      throw StateError('Token Agora belum tersedia. Periksa konfigurasi server.');
    }

    final engine = createAgoraRtcEngine();
    _engine = engine;
    await engine.initialize(RtcEngineContext(
      appId: appId,
      channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
    ));
    await engine.enableAudio();
    await engine.setClientRole(role: ClientRoleType.clientRoleBroadcaster);
    engine.registerEventHandler(RtcEngineEventHandler(
      onUserJoined: (connection, remoteUid, elapsed) => onUserJoined(remoteUid),
      onUserOffline: (connection, remoteUid, reason) => onUserLeft(remoteUid),
      onError: (err, message) => onError('$err: $message'),
    ));
    await engine.joinChannel(
      token: token,
      channelId: roomId,
      uid: uid,
      options: const ChannelMediaOptions(
        channelProfile: ChannelProfileType.channelProfileLiveBroadcasting,
        clientRoleType: ClientRoleType.clientRoleBroadcaster,
        publishMicrophoneTrack: true,
        autoSubscribeAudio: true,
        autoSubscribeVideo: false,
      ),
    );
    _joined = true;
  }

  Future<void> setMuted(bool muted) async {
    _muted = muted;
    await _engine?.muteLocalAudioStream(muted);
  }

  Future<void> leave() async {
    final engine = _engine;
    if (engine == null) return;
    try {
      await engine.leaveChannel();
      await engine.release();
    } finally {
      _engine = null;
      _joined = false;
      _muted = false;
    }
  }
}
