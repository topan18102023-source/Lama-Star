import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../config/app_config.dart';
import '../models/app_user.dart';

class AuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static final FirebaseFirestore _db = FirebaseFirestore.instance;

  static Future<AppUser> signIn({
    required String email,
    required String password,
  }) async {
    if (!AppConfig.useFirebase) return AppUser.demo();

    final credential = await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final user = credential.user;
    if (user == null) throw StateError('Login gagal. Pengguna tidak ditemukan.');

    final snapshot = await _db.collection('users').doc(user.uid).get();
    final data = snapshot.data() ?? <String, dynamic>{};
    return AppUser(
      id: user.uid,
      name: data['displayName'] as String? ?? user.displayName ?? 'Pengguna',
      email: user.email ?? email,
      coins: (data['coins'] as num?)?.toInt() ?? 0,
      diamonds: (data['diamonds'] as num?)?.toInt() ?? 0,
      role: data['role'] as String? ?? 'member',
    );
  }

  static Future<AppUser> register({
    required String name,
    required String email,
    required String password,
  }) async {
    if (!AppConfig.useFirebase) return AppUser.demo();

    final credential = await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final user = credential.user;
    if (user == null) throw StateError('Pendaftaran gagal.');

    await user.updateDisplayName(name.trim());
    await _db.collection('users').doc(user.uid).set({
      'displayName': name.trim(),
      'email': email.trim(),
      'role': 'member',
      'coins': 0,
      'diamonds': 0,
      'createdAt': FieldValue.serverTimestamp(),
    });

    return AppUser(
      id: user.uid,
      name: name.trim(),
      email: email.trim(),
      coins: 0,
      diamonds: 0,
    );
  }

  static Future<void> signOut() async {
    if (AppConfig.useFirebase) await _auth.signOut();
  }
}
