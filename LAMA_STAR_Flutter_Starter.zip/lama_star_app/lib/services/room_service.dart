import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../config/app_config.dart';
import '../models/voice_room.dart';

class RoomService {
  static FirebaseFunctions get _functions => FirebaseFunctions.instanceFor(
        region: AppConfig.functionsRegion,
      );

  static Stream<List<VoiceRoom>> watchRooms() {
    if (!AppConfig.useFirebase) return Stream.value(VoiceRoom.demoRooms);
    return FirebaseFirestore.instance
        .collection('rooms')
        .orderBy('createdAt', descending: true)
        .limit(50)
        .snapshots()
        .map((snapshot) => snapshot.docs
            .map((doc) => VoiceRoom.fromMap(doc.id, doc.data()))
            .toList());
  }

  static Future<String> createRoom({
    required String title,
    required String topic,
    required bool isPrivate,
    String? password,
  }) async {
    if (!AppConfig.useFirebase) {
      throw StateError('Pembuatan room tersimpan membutuhkan Firebase.');
    }
    final result = await _functions.httpsCallable('createRoom').call({
      'title': title.trim(),
      'topic': topic.trim(),
      'isPrivate': isPrivate,
      if (isPrivate) 'password': password ?? '',
    });
    return (result.data as Map)['roomId'] as String;
  }

  static Future<String> joinRoom({
    required String roomId,
    String? password,
  }) async {
    if (!AppConfig.useFirebase) return 'host';
    final result = await _functions.httpsCallable('joinRoom').call({
      'roomId': roomId,
      if (password != null) 'password': password,
    });
    return (result.data as Map)['role'] as String? ?? 'member';
  }

  static Future<void> leaveRoom(String roomId) async {
    if (!AppConfig.useFirebase) return;
    await _functions.httpsCallable('leaveRoom').call({'roomId': roomId});
  }

  static Stream<List<Map<String, dynamic>>> watchMembers(String roomId) {
    if (!AppConfig.useFirebase) {
      return Stream.value([
        {'uid': 'demo-user-001', 'displayName': 'Bintang LAMA', 'role': 'host', 'isMuted': false, 'handRaised': false},
        {'uid': 'demo-user-002', 'displayName': 'Nadia', 'role': 'moderator', 'isMuted': false, 'handRaised': true},
        {'uid': 'demo-user-003', 'displayName': 'Raka', 'role': 'member', 'isMuted': true, 'handRaised': false},
        {'uid': 'demo-user-004', 'displayName': 'Dimas', 'role': 'member', 'isMuted': false, 'handRaised': false},
      ]);
    }
    return FirebaseFirestore.instance
        .collection('rooms')
        .doc(roomId)
        .collection('members')
        .orderBy('joinedAt')
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => doc.data()).toList());
  }

  static Future<void> updateMyPresence(
    String roomId, {
    bool? isMuted,
    bool? handRaised,
  }) async {
    if (!AppConfig.useFirebase) return;
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) throw StateError('Silakan login terlebih dahulu.');
    final updates = <String, dynamic>{'updatedAt': FieldValue.serverTimestamp()};
    if (isMuted != null) updates['isMuted'] = isMuted;
    if (handRaised != null) updates['handRaised'] = handRaised;
    await FirebaseFirestore.instance
        .collection('rooms')
        .doc(roomId)
        .collection('members')
        .doc(uid)
        .update(updates);
  }
}
