import 'package:flutter/material.dart';

import '../models/voice_room.dart';

class AdminPanelScreen extends StatelessWidget {
  const AdminPanelScreen({super.key, required this.room});
  final VoiceRoom room;

  static const background = Color(0xFF100D22);
  static const panel = Color(0xFF1D1835);
  static const accent = Color(0xFF9A6BFF);
  static const muted = Color(0xFFB8B1D0);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      appBar: AppBar(
        backgroundColor: background,
        title: const Text('Admin Panel', style: TextStyle(fontWeight: FontWeight.bold)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              gradient: const LinearGradient(colors: [Color(0xFF6B43C8), Color(0xFFB34F9B)]),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('PANEL PENGELOLA ROOM', style: TextStyle(color: Colors.white70, fontSize: 10, letterSpacing: 1.2)),
              const SizedBox(height: 8),
              Text(room.title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
              const SizedBox(height: 5),
              const Text('Kelola moderator, anggota, dan keamanan room.', style: TextStyle(color: Colors.white70)),
            ]),
          ),
          const SizedBox(height: 18),
          const Row(children: [
            Expanded(child: _AdminStat(title: 'Anggota', value: '—', icon: Icons.people_alt_outlined)),
            SizedBox(width: 10),
            Expanded(child: _AdminStat(title: 'Moderator', value: '—', icon: Icons.shield_outlined)),
            SizedBox(width: 10),
            Expanded(child: _AdminStat(title: 'Status', value: 'LIVE', icon: Icons.graphic_eq_rounded)),
          ]),
          const SizedBox(height: 24),
          const Text('Manajemen room', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          _AdminAction(icon: Icons.person_add_alt_1_rounded, title: 'Atur moderator', subtitle: 'Pilih anggota yang membantu host', onTap: () => _notice(context, 'Penetapan moderator perlu endpoint admin yang akan diaktifkan berikutnya.')),
          _AdminAction(icon: Icons.volume_off_outlined, title: 'Kontrol mikrofon anggota', subtitle: 'Mute anggota yang mengganggu room', onTap: () => _notice(context, 'Kontrol mute anggota akan dihubungkan ke backend berikutnya.')),
          _AdminAction(icon: Icons.lock_outline, title: 'Keamanan room', subtitle: 'Privasi dan password room', onTap: () => _notice(context, 'Pengaturan keamanan room akan ditambahkan.')),
          _AdminAction(icon: Icons.campaign_outlined, title: 'Pengumuman', subtitle: 'Kirim pesan kepada semua anggota', onTap: () => _notice(context, 'Pengumuman room belum diaktifkan.')),
          _AdminAction(icon: Icons.block_outlined, title: 'Daftar blokir', subtitle: 'Kelola anggota yang diblokir', onTap: () => _notice(context, 'Daftar blokir belum diaktifkan.')),
          const SizedBox(height: 20),
          const Text('Catatan: halaman ini adalah kerangka panel admin. Aksi pengelolaan lanjutan harus memakai Cloud Functions dengan pemeriksaan role host/admin di server.', style: TextStyle(color: muted, fontSize: 12, height: 1.5)),
        ],
      ),
    );
  }

  static void _notice(BuildContext context, String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }
}

class _AdminStat extends StatelessWidget {
  const _AdminStat({required this.title, required this.value, required this.icon});
  final String title;
  final String value;
  final IconData icon;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(color: AdminPanelScreen.panel, borderRadius: BorderRadius.circular(16)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: AdminPanelScreen.accent),
          const SizedBox(height: 12),
          Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
          Text(title, style: const TextStyle(color: AdminPanelScreen.muted, fontSize: 10)),
        ]),
      );
}

class _AdminAction extends StatelessWidget {
  const _AdminAction({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Card(
        color: AdminPanelScreen.panel,
        margin: const EdgeInsets.only(bottom: 9),
        child: ListTile(
          leading: Icon(icon, color: AdminPanelScreen.accent),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: Text(subtitle, style: const TextStyle(color: AdminPanelScreen.muted, fontSize: 12)),
          trailing: const Icon(Icons.chevron_right, color: AdminPanelScreen.muted),
          onTap: onTap,
        ),
      );
}
