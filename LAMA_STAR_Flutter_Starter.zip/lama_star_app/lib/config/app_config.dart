class AppConfig {
  // Jalankan dengan --dart-define=USE_FIREBASE=true setelah FlutterFire disiapkan.
  static const bool useFirebase = bool.fromEnvironment(
    'USE_FIREBASE',
    defaultValue: false,
  );

  static const String functionsRegion = String.fromEnvironment(
    'FIREBASE_FUNCTIONS_REGION',
    defaultValue: 'asia-southeast1',
  );
}
