import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'config/app_config.dart';
import 'firebase_options.dart';
import 'models/app_user.dart';
import 'models/voice_room.dart';
import 'screens/admin_panel_screen.dart';
import 'services/agora_service.dart';
import 'services/auth_service.dart';
import 'services/room_service.dart';

const _ink = Color(0xFF100D22);
const _panel = Color(0xFF1D1835);
const _purple = Color(0xFF9A6BFF);
const _pink = Color(0xFFFF72B6);
const _mutedText = Color(0xFFB8B1D0);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (AppConfig.useFirebase) {
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );
  }
  runApp(const LamaStarApp());
}

class LamaStarApp extends StatelessWidget {
  const LamaStarApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LAMA STAR',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: _ink,
        colorScheme: ColorScheme.fromSeed(
          seedColor: _purple,
          brightness: Brightness.dark,
          surface: _panel,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white.withValues(alpha: .06),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: Colors.white.withValues(alpha: .08)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: _purple),
          ),
          hintStyle: const TextStyle(color: _mutedText),
          labelStyle: const TextStyle(color: _mutedText),
        ),
      ),
      home: AppConfig.useFirebase ? const FirebaseGate() : const LoginScreen(),
    );
  }
}

class FirebaseGate extends StatelessWidget {
  const FirebaseGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const _LoadingScreen();
        }
        final firebaseUser = snapshot.data;
        if (firebaseUser == null) return const LoginScreen();
        return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
          future: FirebaseFirestore.instance.collection('users').doc(firebaseUser.uid).get(),
          builder: (context, profile) {
            if (profile.connectionState == ConnectionState.waiting) {
              return const _LoadingScreen();
            }
            final data = profile.data?.data() ?? <String, dynamic>{};
            return HomeScreen(
              user: AppUser(
                id: firebaseUser.uid,
                name: data['displayName'] as String? ?? firebaseUser.displayName ?? 'Pengguna',
                email: firebaseUser.email ?? '',
                coins: (data['coins'] as num?)?.toInt() ?? 0,
                diamonds: (data['diamonds'] as num?)?.toInt() ?? 0,
                role: data['role'] as String? ?? 'member',
              ),
            );
          },
        );
      },
    );
  }
}

class _LoadingScreen extends StatelessWidget {
  const _LoadingScreen();

  @override
  Widget build(BuildContext context) => const Scaffold(
        body: Center(child: CircularProgressIndicator(color: _purple)),
      );
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _register = false;
  bool _loading = false;
  bool _hidePassword = true;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    try {
      final user = _register
          ? await AuthService.register(
              name: _name.text,
              email: _email.text,
              password: _password.text,
            )
          : await AuthService.signIn(
              email: _email.text,
              password: _password.text,
            );
      if (!mounted) return;
      if (AppConfig.useFirebase) {
        // FirebaseGate akan berpindah otomatis mengikuti authStateChanges.
        return;
      }
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => HomeScreen(user: user)),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Tidak dapat masuk: $error')),
      );
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _demoLogin() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => HomeScreen(user: AppUser.demo())),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF2A1750), _ink, Color(0xFF17132D)],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 440),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    const SizedBox(height: 24),
                    Center(
                      child: Container(
                        width: 92,
                        height: 92,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: const LinearGradient(colors: [_purple, _pink]),
                          boxShadow: [
                            BoxShadow(color: _purple.withValues(alpha: .34), blurRadius: 34),
                          ],
                        ),
                        child: const Icon(Icons.graphic_eq_rounded, size: 48, color: Colors.white),
                      ),
                    ),
                    const SizedBox(height: 20),
                    const Text(
                      'LAMA STAR',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 31, fontWeight: FontWeight.w900, letterSpacing: 3),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Temukan teman, mulai obrolan, dan bersinar bersama.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: _mutedText, height: 1.5),
                    ),
                    const SizedBox(height: 32),
                    Container(
                      padding: const EdgeInsets.all(22),
                      decoration: BoxDecoration(
                        color: _panel.withValues(alpha: .92),
                        borderRadius: BorderRadius.circular(26),
                        border: Border.all(color: Colors.white.withValues(alpha: .08)),
                      ),
                      child: Form(
                        key: _formKey,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              _register ? 'Buat akun baru' : 'Selamat datang kembali',
                              style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 18),
                            if (_register) ...[
                              TextFormField(
                                controller: _name,
                                decoration: const InputDecoration(labelText: 'Nama pengguna', prefixIcon: Icon(Icons.person_outline)),
                                validator: (value) => (value == null || value.trim().isEmpty) ? 'Masukkan nama.' : null,
                              ),
                              const SizedBox(height: 12),
                            ],
                            TextFormField(
                              controller: _email,
                              keyboardType: TextInputType.emailAddress,
                              decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email_outlined)),
                              validator: (value) => (value == null || !value.contains('@')) ? 'Masukkan email yang valid.' : null,
                            ),
                            const SizedBox(height: 12),
                            TextFormField(
                              controller: _password,
                              obscureText: _hidePassword,
                              decoration: InputDecoration(
                                labelText: 'Password',
                                prefixIcon: const Icon(Icons.lock_outline),
                                suffixIcon: IconButton(
                                  onPressed: () => setState(() => _hidePassword = !_hidePassword),
                                  icon: Icon(_hidePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined),
                                ),
                              ),
                              validator: (value) => (value == null || value.length < 6) ? 'Password minimal 6 karakter.' : null,
                            ),
                            const SizedBox(height: 20),
                            FilledButton(
                              onPressed: _loading ? null : _submit,
                              style: FilledButton.styleFrom(
                                backgroundColor: _purple,
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(vertical: 16),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                              ),
                              child: _loading
                                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))
                                  : Text(_register ? 'DAFTAR SEKARANG' : 'MASUK', style: const TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
                            ),
                            const SizedBox(height: 8),
                            TextButton(
                              onPressed: () => setState(() => _register = !_register),
                              child: Text(_register ? 'Sudah punya akun? Masuk' : 'Belum punya akun? Daftar'),
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 18),
                    OutlinedButton.icon(
                      onPressed: _demoLogin,
                      icon: const Icon(Icons.rocket_launch_outlined),
                      label: const Text('COBA MODE DEMO'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: BorderSide(color: Colors.white.withValues(alpha: .22)),
                        padding: const EdgeInsets.symmetric(vertical: 15),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                      ),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      AppConfig.useFirebase ? 'Firebase aktif' : 'Mode demo — belum terhubung ke server',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: _mutedText, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.user});
  final AppUser user;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late List<VoiceRoom> _demoRooms;
  int _selectedTab = 0;
  String _category = 'Semua';

  @override
  void initState() {
    super.initState();
    _demoRooms = List.of(VoiceRoom.demoRooms);
  }

  Future<void> _createRoom() async {
    final result = await showDialog<_RoomDraft>(
      context: context,
      builder: (_) => const _CreateRoomDialog(),
    );
    if (result == null) return;

    try {
      if (AppConfig.useFirebase) {
        await RoomService.createRoom(
          title: result.title,
          topic: result.topic,
          isPrivate: result.isPrivate,
          password: result.password,
        );
      } else {
        setState(() {
          _demoRooms.insert(
            0,
            VoiceRoom(
              id: 'demo-${DateTime.now().microsecondsSinceEpoch}',
              title: result.title,
              topic: result.topic,
              memberCount: 1,
              isPrivate: result.isPrivate,
              ownerId: widget.user.id,
              coverEmoji: '✨',
            ),
          );
        });
      }
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Room berhasil dibuat.')));
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal membuat room: $error')));
    }
  }

  Future<void> _openRoom(VoiceRoom room) async {
    String? password;
    if (room.isPrivate) {
      password = await showDialog<String>(
        context: context,
        builder: (_) => const _RoomPasswordDialog(),
      );
      if (password == null) return;
    }
    try {
      final role = await RoomService.joinRoom(roomId: room.id, password: password);
      if (!mounted) return;
      Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => VoiceRoomScreen(room: room, user: widget.user, role: role),
      ));
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Tidak dapat masuk room: $error')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final Stream<List<VoiceRoom>> roomStream = AppConfig.useFirebase
        ? RoomService.watchRooms()
        : Stream.value(_demoRooms);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _ink,
        title: Row(
          children: [
            const Icon(Icons.auto_awesome, color: _pink, size: 22),
            const SizedBox(width: 9),
            const Text('LAMA STAR', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.4)),
          ],
        ),
        actions: [
          IconButton(onPressed: () => _showNotice(context, 'Notifikasi akan tersedia setelah modul notifikasi diaktifkan.'), icon: const Icon(Icons.notifications_none_rounded)),
          const SizedBox(width: 4),
          CircleAvatar(
            radius: 17,
            backgroundColor: _purple,
            child: Text(widget.user.name.isNotEmpty ? widget.user.name[0].toUpperCase() : 'L', style: const TextStyle(fontWeight: FontWeight.bold)),
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: _selectedTab == 0
          ? _buildDiscover(roomStream)
          : _selectedTab == 1
              ? _buildPopular(roomStream)
              : _buildProfile(),
      floatingActionButton: _selectedTab == 0
          ? FloatingActionButton.extended(
              onPressed: _createRoom,
              backgroundColor: _purple,
              foregroundColor: Colors.white,
              icon: const Icon(Icons.add_rounded),
              label: const Text('Buat Room'),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        backgroundColor: _panel,
        indicatorColor: _purple.withValues(alpha: .25),
        selectedIndex: _selectedTab,
        onDestinationSelected: (index) => setState(() => _selectedTab = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.explore_outlined), selectedIcon: Icon(Icons.explore), label: 'Jelajah'),
          NavigationDestination(icon: Icon(Icons.local_fire_department_outlined), selectedIcon: Icon(Icons.local_fire_department), label: 'Populer'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }

  Widget _buildDiscover(Stream<List<VoiceRoom>> rooms) {
    return StreamBuilder<List<VoiceRoom>>(
      stream: rooms,
      builder: (context, snapshot) {
        final allRooms = snapshot.data ?? _demoRooms;
        final visible = _category == 'Semua'
            ? allRooms
            : allRooms.where((room) => _matchesCategory(room, _category)).toList();
        return ListView(
          padding: const EdgeInsets.fromLTRB(18, 10, 18, 100),
          children: [
            _welcomeBanner(),
            const SizedBox(height: 18),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Room pilihan', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                Text('${allRooms.length} room', style: const TextStyle(color: _mutedText, fontSize: 12)),
              ],
            ),
            const SizedBox(height: 12),
            _categoryChips(),
            const SizedBox(height: 12),
            if (snapshot.connectionState == ConnectionState.waiting && AppConfig.useFirebase)
              const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator(color: _purple))),
            if (visible.isEmpty)
              const Padding(padding: EdgeInsets.all(28), child: Center(child: Text('Belum ada room di kategori ini.', style: TextStyle(color: _mutedText)))),
            ...visible.map((room) => _RoomCard(room: room, onTap: () => _openRoom(room))),
            const SizedBox(height: 16),
            const Text('Fitur utama', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            const Row(
              children: [
                Expanded(child: _FeatureTile(icon: Icons.mic_rounded, title: 'Voice chat', subtitle: 'Ngobrol langsung')),
                SizedBox(width: 10),
                Expanded(child: _FeatureTile(icon: Icons.card_giftcard_rounded, title: 'Virtual gift', subtitle: 'Kirim hadiah')),
                SizedBox(width: 10),
                Expanded(child: _FeatureTile(icon: Icons.shield_rounded, title: 'Moderator', subtitle: 'Kelola room')),
              ],
            ),
          ],
        );
      },
    );
  }

  Widget _welcomeBanner() {
    return Container(
      padding: const EdgeInsets.all(19),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(colors: [Color(0xFF6B43C8), Color(0xFFB34F9B)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        boxShadow: [BoxShadow(color: _purple.withValues(alpha: .18), blurRadius: 22, offset: const Offset(0, 10))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Halo, ${widget.user.name} 👋', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 5),
                  const Text('Suaramu, temanmu, ceritamu.', style: TextStyle(color: Colors.white70)),
                ]),
              ),
              const Icon(Icons.graphic_eq_rounded, size: 48, color: Colors.white70),
            ],
          ),
          const SizedBox(height: 17),
          Row(
            children: [
              _BalancePill(icon: Icons.monetization_on_rounded, value: widget.user.coins.toString(), label: 'Coin'),
              const SizedBox(width: 8),
              _BalancePill(icon: Icons.diamond_rounded, value: widget.user.diamonds.toString(), label: 'Diamond'),
              const Spacer(),
              TextButton(onPressed: () => _showNotice(context, 'Toko coin dan diamond belum diaktifkan.'), child: const Text('Top up  ›', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _categoryChips() {
    const categories = ['Semua', 'Musik', 'Santai', 'Diskusi'];
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: categories.map((item) => Padding(
          padding: const EdgeInsets.only(right: 8),
          child: ChoiceChip(
            label: Text(item),
            selected: _category == item,
            onSelected: (_) => setState(() => _category = item),
            selectedColor: _purple,
            backgroundColor: _panel,
            labelStyle: TextStyle(color: _category == item ? Colors.white : _mutedText, fontWeight: FontWeight.w600),
            side: BorderSide.none,
          ),
        )).toList(),
      ),
    );
  }

  Widget _buildPopular(Stream<List<VoiceRoom>> rooms) {
    return StreamBuilder<List<VoiceRoom>>(
      stream: rooms,
      builder: (context, snapshot) {
        final list = List<VoiceRoom>.from(snapshot.data ?? _demoRooms)
          ..sort((a, b) => b.memberCount.compareTo(a.memberCount));
        return ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const Text('Room terpopuler', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('Temukan obrolan yang sedang ramai.', style: TextStyle(color: _mutedText)),
            const SizedBox(height: 18),
            ...list.map((room) => _RoomCard(room: room, onTap: () => _openRoom(room))),
          ],
        );
      },
    );
  }

  Widget _buildProfile() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const SizedBox(height: 18),
        CircleAvatar(radius: 43, backgroundColor: _purple, child: Text(widget.user.name.isNotEmpty ? widget.user.name[0].toUpperCase() : 'L', style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold))),
        const SizedBox(height: 12),
        Text(widget.user.name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        Text(widget.user.email.isEmpty ? 'Mode demo' : widget.user.email, textAlign: TextAlign.center, style: const TextStyle(color: _mutedText)),
        const SizedBox(height: 22),
        _ProfileAction(icon: Icons.wallet_outlined, title: 'Dompet', subtitle: '${widget.user.coins} coin • ${widget.user.diamonds} diamond', onTap: () => _showNotice(context, 'Dompet akan dihubungkan ke sistem transaksi.')),
        _ProfileAction(icon: Icons.workspace_premium_outlined, title: 'Level & lencana', subtitle: 'Lihat pencapaian akun', onTap: () => _showNotice(context, 'Level pengguna belum diaktifkan.')),
        _ProfileAction(icon: Icons.settings_outlined, title: 'Pengaturan', subtitle: 'Akun dan preferensi', onTap: () => _showNotice(context, 'Pengaturan akan ditambahkan.')),
        const SizedBox(height: 18),
        OutlinedButton.icon(
          onPressed: () async {
            await AuthService.signOut();
            if (!context.mounted) return;
            Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
          },
          icon: const Icon(Icons.logout),
          label: const Text('Keluar akun'),
          style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 14)),
        ),
      ],
    );
  }

  bool _matchesCategory(VoiceRoom room, String category) {
    final value = '${room.title} ${room.topic}'.toLowerCase();
    switch (category) {
      case 'Musik': return value.contains('musik') || value.contains('lagu') || value.contains('karaoke');
      case 'Santai': return value.contains('santai') || value.contains('malam') || value.contains('teman');
      case 'Diskusi': return value.contains('diskusi') || value.contains('bicara') || value.contains('cerita');
      default: return true;
    }
  }
}

class _RoomCard extends StatelessWidget {
  const _RoomCard({required this.room, required this.onTap});
  final VoiceRoom room;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      color: _panel,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: Colors.white.withValues(alpha: .05))),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              Container(
                width: 62,
                height: 62,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(17),
                  gradient: const LinearGradient(colors: [Color(0xFF5C3AA5), Color(0xFFB34F9B)]),
                ),
                child: Text(room.coverEmoji, style: const TextStyle(fontSize: 29)),
              ),
              const SizedBox(width: 13),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [
                      Flexible(child: Text(room.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15))),
                      if (room.isPrivate) ...[
                        const SizedBox(width: 6),
                        const Icon(Icons.lock_rounded, color: _pink, size: 14),
                      ],
                    ]),
                    const SizedBox(height: 5),
                    Text(room.topic, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _mutedText, fontSize: 12)),
                    const SizedBox(height: 9),
                    Row(children: [
                      const Icon(Icons.headphones_rounded, size: 14, color: _purple),
                      const SizedBox(width: 5),
                      Text('${room.memberCount} online', style: const TextStyle(color: _mutedText, fontSize: 11)),
                      const SizedBox(width: 12),
                      const Icon(Icons.circle, size: 6, color: Color(0xFF64DDA0)),
                      const SizedBox(width: 5),
                      const Text('LIVE', style: TextStyle(color: Color(0xFF64DDA0), fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
                    ]),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.chevron_right_rounded, color: _mutedText),
            ],
          ),
        ),
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 13),
      decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(15)),
      child: Column(children: [Icon(icon, color: _pink, size: 21), const SizedBox(height: 8), Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 11)), const SizedBox(height: 3), Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: _mutedText, fontSize: 9))]),
    );
  }
}

class _BalancePill extends StatelessWidget {
  const _BalancePill({required this.icon, required this.value, required this.label});
  final IconData icon;
  final String value;
  final String label;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(color: Colors.black.withValues(alpha: .18), borderRadius: BorderRadius.circular(30)),
        child: Row(children: [Icon(icon, size: 16, color: const Color(0xFFFFD166)), const SizedBox(width: 5), Text(value, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(width: 4), Text(label, style: const TextStyle(color: Colors.white70, fontSize: 10))]),
      );
}

class _ProfileAction extends StatelessWidget {
  const _ProfileAction({required this.icon, required this.title, required this.subtitle, required this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        tileColor: _panel,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        leading: Icon(icon, color: _pink),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, style: const TextStyle(color: _mutedText, fontSize: 12)),
        trailing: const Icon(Icons.chevron_right, color: _mutedText),
        onTap: onTap,
      );
}

class VoiceRoomScreen extends StatefulWidget {
  const VoiceRoomScreen({super.key, required this.room, required this.user, required this.role});
  final VoiceRoom room;
  final AppUser user;
  final String role;

  @override
  State<VoiceRoomScreen> createState() => _VoiceRoomScreenState();
}

class _VoiceRoomScreenState extends State<VoiceRoomScreen> {
  final AgoraService _agora = AgoraService();
  bool _muted = false;
  bool _handRaised = false;
  bool _connecting = true;
  String _status = 'Menyiapkan room...';
  final Set<int> _remoteUids = {};

  bool get _canManage => widget.role == 'host' || widget.role == 'moderator' || widget.user.role == 'admin';

  @override
  void initState() {
    super.initState();
    _connect();
  }

  Future<void> _connect() async {
    if (!AppConfig.useFirebase) {
      setState(() {
        _connecting = false;
        _status = 'Mode demo — suara belum terhubung';
      });
      return;
    }
    try {
      await _agora.join(
        roomId: widget.room.id,
        onUserJoined: (uid) { if (mounted) setState(() => _remoteUids.add(uid)); },
        onUserLeft: (uid) { if (mounted) setState(() => _remoteUids.remove(uid)); },
        onError: (message) { if (mounted) setState(() => _status = message); },
      );
      if (mounted) setState(() { _connecting = false; _status = 'Terhubung ke voice room'; });
    } catch (error) {
      if (mounted) setState(() { _connecting = false; _status = 'Voice belum aktif: $error'; });
    }
  }

  Future<void> _toggleMute() async {
    final next = !_muted;
    try {
      await _agora.setMuted(next);
      await RoomService.updateMyPresence(widget.room.id, isMuted: next);
      if (mounted) setState(() => _muted = next);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Tidak dapat mengubah mikrofon: $error')));
    }
  }

  Future<void> _toggleHand() async {
    final next = !_handRaised;
    try {
      await RoomService.updateMyPresence(widget.room.id, handRaised: next);
      if (mounted) setState(() => _handRaised = next);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Gagal mengangkat tangan: $error')));
    }
  }

  Future<void> _leave() async {
    await _agora.leave();
    try { await RoomService.leaveRoom(widget.room.id); } catch (_) {}
    if (mounted) Navigator.of(context).pop();
  }

  void _showGiftSheet() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: _panel,
      showDragHandle: true,
      builder: (context) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 28),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Kirim hadiah', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Row(children: [
            _GiftItem(emoji: '🌹', name: 'Mawar', price: '10 coin', onTap: () => Navigator.pop(context)),
            _GiftItem(emoji: '💎', name: 'Diamond', price: '50 coin', onTap: () => Navigator.pop(context)),
            _GiftItem(emoji: '🚀', name: 'Roket', price: '100 coin', onTap: () => Navigator.pop(context)),
            _GiftItem(emoji: '👑', name: 'Mahkota', price: '500 coin', onTap: () => Navigator.pop(context)),
          ]),
          const SizedBox(height: 10),
          const Text('Tampilan hadiah demo. Transaksi belum dihubungkan ke backend.', style: TextStyle(color: _mutedText, fontSize: 12)),
        ]),
      ),
    );
  }

  void _showMembers() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: _panel,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(context).size.height * .62,
          child: Column(children: [
            const Padding(padding: EdgeInsets.all(14), child: Text('Anggota room', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold))),
            Expanded(
              child: StreamBuilder<List<Map<String, dynamic>>>(
                stream: RoomService.watchMembers(widget.room.id),
                builder: (context, snapshot) {
                  final members = snapshot.data ?? [];
                  if (members.isEmpty) return const Center(child: Text('Belum ada anggota.', style: TextStyle(color: _mutedText)));
                  return ListView.builder(
                    itemCount: members.length,
                    itemBuilder: (context, index) {
                      final member = members[index];
                      final name = member['displayName'] as String? ?? 'Pengguna';
                      final role = member['role'] as String? ?? 'member';
                      return ListTile(
                        leading: CircleAvatar(backgroundColor: _purple, child: Text(name.isNotEmpty ? name[0].toUpperCase() : '?')),
                        title: Text(name),
                        subtitle: Text(role.toUpperCase(), style: const TextStyle(color: _mutedText, fontSize: 10)),
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          if (member['handRaised'] == true) const Icon(Icons.back_hand_rounded, color: Color(0xFFFFD166), size: 18),
                          if (member['isMuted'] == true) const Padding(padding: EdgeInsets.only(left: 8), child: Icon(Icons.mic_off_rounded, color: _mutedText, size: 18)),
                        ]),
                      );
                    },
                  );
                },
              ),
            ),
          ]),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _agora.leave();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: _ink,
        leading: IconButton(icon: const Icon(Icons.keyboard_arrow_down_rounded), onPressed: _leave),
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.room.title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const Text('LAMA STAR VOICE ROOM', style: TextStyle(color: _mutedText, fontSize: 9, letterSpacing: 1.2)),
        ]),
        actions: [
          IconButton(onPressed: _showMembers, icon: const Icon(Icons.people_alt_outlined)),
          if (_canManage) IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => AdminPanelScreen(room: widget.room))), icon: const Icon(Icons.admin_panel_settings_outlined)),
        ],
      ),
      body: Column(
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(18, 5, 18, 18),
            decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFF2A1750), _ink], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: const Color(0xFF64DDA0).withValues(alpha: .14), borderRadius: BorderRadius.circular(30)), child: const Row(children: [Icon(Icons.circle, color: Color(0xFF64DDA0), size: 7), SizedBox(width: 6), Text('LIVE', style: TextStyle(color: Color(0xFF64DDA0), fontWeight: FontWeight.bold, fontSize: 10))])),
                const SizedBox(width: 8),
                Expanded(child: Text(_status, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _mutedText, fontSize: 11))),
                if (_connecting) const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
              ]),
              const SizedBox(height: 12),
              Text(widget.room.topic, style: const TextStyle(color: Colors.white70)),
            ]),
          ),
          Expanded(
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: RoomService.watchMembers(widget.room.id),
              builder: (context, snapshot) {
                final members = snapshot.data ?? [];
                return GridView.builder(
                  padding: const EdgeInsets.all(18),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 13, crossAxisSpacing: 13, childAspectRatio: 1.17),
                  itemCount: members.isEmpty ? 4 : members.length,
                  itemBuilder: (context, index) {
                    if (members.isEmpty) return const _SpeakerTile(name: 'Menunggu anggota', role: 'SEAT KOSONG', emoji: '🎧', muted: true, raised: false);
                    final member = members[index];
                    final name = member['displayName'] as String? ?? 'Pengguna';
                    final role = member['role'] as String? ?? 'member';
                    final muted = member['isMuted'] as bool? ?? false;
                    final raised = member['handRaised'] as bool? ?? false;
                    final emoji = name.isEmpty ? '⭐' : String.fromCharCode(0x1F600 + (name.codeUnitAt(0) % 70));
                    return _SpeakerTile(name: name, role: role.toUpperCase(), emoji: emoji, muted: muted, raised: raised, isMe: member['uid'] == widget.user.id);
                  },
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 22),
            decoration: BoxDecoration(color: _panel, border: Border(top: BorderSide(color: Colors.white.withValues(alpha: .06)))),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _RoomControl(icon: _muted ? Icons.mic_off_rounded : Icons.mic_rounded, label: _muted ? 'Unmute' : 'Mute', active: !_muted, onTap: _toggleMute),
                _RoomControl(icon: _handRaised ? Icons.back_hand_rounded : Icons.front_hand_outlined, label: _handRaised ? 'Turunkan' : 'Raise hand', active: _handRaised, onTap: _toggleHand),
                _RoomControl(icon: Icons.card_giftcard_rounded, label: 'Gift', onTap: _showGiftSheet),
                _RoomControl(icon: Icons.people_alt_outlined, label: 'Anggota', onTap: _showMembers),
                _RoomControl(icon: Icons.call_end_rounded, label: 'Keluar', danger: true, onTap: _leave),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SpeakerTile extends StatelessWidget {
  const _SpeakerTile({required this.name, required this.role, required this.emoji, required this.muted, required this.raised, this.isMe = false});
  final String name;
  final String role;
  final String emoji;
  final bool muted;
  final bool raised;
  final bool isMe;

  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(21), border: Border.all(color: isMe ? _purple : Colors.white.withValues(alpha: .06), width: isMe ? 1.5 : 1)),
        child: Stack(children: [
          Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
            Container(width: 61, height: 61, alignment: Alignment.center, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [_purple, _pink])), child: Text(emoji, style: const TextStyle(fontSize: 29))),
            const SizedBox(height: 9),
            Padding(padding: const EdgeInsets.symmetric(horizontal: 9), child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold))),
            const SizedBox(height: 3),
            Text(role, style: const TextStyle(color: _mutedText, fontSize: 9, letterSpacing: .5)),
          ])),
          if (muted) const Positioned(right: 9, top: 9, child: Icon(Icons.mic_off_rounded, size: 16, color: _mutedText)),
          if (raised) const Positioned(left: 9, top: 9, child: Icon(Icons.back_hand_rounded, size: 17, color: Color(0xFFFFD166))),
          if (isMe) const Positioned(right: 9, bottom: 8, child: Text('KAMU', style: TextStyle(color: _purple, fontWeight: FontWeight.bold, fontSize: 8))),
        ]),
      );
}

class _RoomControl extends StatelessWidget {
  const _RoomControl({required this.icon, required this.label, required this.onTap, this.active = false, this.danger = false});
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool active;
  final bool danger;
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(width: 47, height: 47, decoration: BoxDecoration(color: danger ? const Color(0xFFE84A68) : active ? _purple.withValues(alpha: .24) : Colors.white.withValues(alpha: .07), borderRadius: BorderRadius.circular(15)), child: Icon(icon, color: danger ? Colors.white : active ? _pink : Colors.white, size: 21)),
          const SizedBox(height: 6),
          Text(label, style: const TextStyle(color: _mutedText, fontSize: 9)),
        ]),
      );
}

class _GiftItem extends StatelessWidget {
  const _GiftItem({required this.emoji, required this.name, required this.price, required this.onTap});
  final String emoji;
  final String name;
  final String price;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Expanded(child: InkWell(onTap: onTap, child: Column(children: [Text(emoji, style: const TextStyle(fontSize: 29)), const SizedBox(height: 5), Text(name, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold)), Text(price, style: const TextStyle(color: _mutedText, fontSize: 9))])));
}

class _CreateRoomDialog extends StatefulWidget {
  const _CreateRoomDialog();
  @override
  State<_CreateRoomDialog> createState() => _CreateRoomDialogState();
}

class _CreateRoomDialogState extends State<_CreateRoomDialog> {
  final _title = TextEditingController();
  final _topic = TextEditingController();
  final _password = TextEditingController();
  bool _private = false;
  @override
  void dispose() { _title.dispose(); _topic.dispose(); _password.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AlertDialog(
        backgroundColor: _panel,
        title: const Text('Buat voice room'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: _title, decoration: const InputDecoration(labelText: 'Nama room')),
          const SizedBox(height: 10),
          TextField(controller: _topic, decoration: const InputDecoration(labelText: 'Topik obrolan')),
          SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('Room privat'), value: _private, onChanged: (value) => setState(() => _private = value)),
          if (_private) TextField(controller: _password, obscureText: true, decoration: const InputDecoration(labelText: 'Password room')),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')),
          FilledButton(onPressed: () {
            if (_title.text.trim().isEmpty || _topic.text.trim().isEmpty || (_private && _password.text.length < 4)) return;
            Navigator.pop(context, _RoomDraft(title: _title.text.trim(), topic: _topic.text.trim(), isPrivate: _private, password: _password.text));
          }, child: const Text('Buat')),
        ],
      );
}

class _RoomPasswordDialog extends StatefulWidget {
  const _RoomPasswordDialog();
  @override
  State<_RoomPasswordDialog> createState() => _RoomPasswordDialogState();
}

class _RoomPasswordDialogState extends State<_RoomPasswordDialog> {
  final _password = TextEditingController();
  @override
  void dispose() { _password.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AlertDialog(
        backgroundColor: _panel,
        title: const Text('Room privat'),
        content: TextField(controller: _password, obscureText: true, decoration: const InputDecoration(labelText: 'Masukkan password room')),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Batal')), FilledButton(onPressed: () => Navigator.pop(context, _password.text), child: const Text('Masuk'))],
      );
}

class _RoomDraft {
  const _RoomDraft({required this.title, required this.topic, required this.isPrivate, this.password});
  final String title;
  final String topic;
  final bool isPrivate;
  final String? password;
}

void _showNotice(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}
