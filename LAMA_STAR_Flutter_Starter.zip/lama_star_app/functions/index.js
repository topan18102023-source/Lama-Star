const crypto = require('node:crypto');
const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { defineSecret } = require('firebase-functions/params');
const { initializeApp } = require('firebase-admin/app');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
const bcrypt = require('bcryptjs');
const { AccessToken2, ServiceRtc } = require('agora-token/src/AccessToken2');

initializeApp();
const db = getFirestore();
const REGION = 'asia-southeast1';
const agoraAppIdSecret = defineSecret('AGORA_APP_ID');
const agoraCertificateSecret = defineSecret('AGORA_APP_CERTIFICATE');

function requireAuth(request) {
  if (!request.auth) {
    throw new HttpsError('unauthenticated', 'Silakan login terlebih dahulu.');
  }
  return request.auth.uid;
}

function textValue(value, field, maxLength) {
  const result = typeof value === 'string' ? value.trim() : '';
  if (!result || result.length > maxLength) {
    throw new HttpsError('invalid-argument', `${field} wajib diisi dan maksimal ${maxLength} karakter.`);
  }
  return result;
}

function createRtcUid(firebaseUid) {
  const digest = crypto.createHash('sha256').update(firebaseUid).digest();
  return (digest.readUInt32BE(0) % 2147483646) + 1;
}

exports.createRoom = onCall({ region: REGION }, async (request) => {
  const uid = requireAuth(request);
  const title = textValue(request.data?.title, 'Nama room', 48);
  const topic = textValue(request.data?.topic, 'Topik room', 120);
  const isPrivate = request.data?.isPrivate === true;
  const password = isPrivate ? textValue(request.data?.password, 'Password room', 64) : '';

  if (isPrivate && password.length < 4) {
    throw new HttpsError('invalid-argument', 'Password room minimal 4 karakter.');
  }

  const userSnapshot = await db.collection('users').doc(uid).get();
  const displayName = userSnapshot.get('displayName') || 'Host LAMA STAR';
  const roomRef = db.collection('rooms').doc();
  const batch = db.batch();

  batch.set(roomRef, {
    title,
    topic,
    isPrivate,
    ownerId: uid,
    memberCount: 1,
    coverEmoji: '✨',
    createdAt: FieldValue.serverTimestamp(),
  });

  batch.set(roomRef.collection('members').doc(uid), {
    uid,
    displayName,
    role: 'host',
    isMuted: false,
    handRaised: false,
    joinedAt: FieldValue.serverTimestamp(),
  });

  if (isPrivate) {
    const passwordHash = await bcrypt.hash(password, 12);
    batch.set(db.collection('roomSecrets').doc(roomRef.id), {
      passwordHash,
      updatedAt: FieldValue.serverTimestamp(),
    });
  }

  await batch.commit();
  return { roomId: roomRef.id };
});

exports.joinRoom = onCall({ region: REGION }, async (request) => {
  const uid = requireAuth(request);
  const roomId = textValue(request.data?.roomId, 'Room ID', 80);
  const roomRef = db.collection('rooms').doc(roomId);
  const roomSnapshot = await roomRef.get();

  if (!roomSnapshot.exists) {
    throw new HttpsError('not-found', 'Room tidak ditemukan.');
  }

  const memberRef = roomRef.collection('members').doc(uid);
  const existingMember = await memberRef.get();
  const isPrivate = roomSnapshot.get('isPrivate') === true;

  if (isPrivate && !existingMember.exists) {
    const password = textValue(request.data?.password, 'Password room', 64);
    const secretSnapshot = await db.collection('roomSecrets').doc(roomId).get();
    const passwordHash = secretSnapshot.get('passwordHash');
    if (!passwordHash || !(await bcrypt.compare(password, passwordHash))) {
      throw new HttpsError('permission-denied', 'Password room salah.');
    }
  }

  if (!existingMember.exists) {
    const userSnapshot = await db.collection('users').doc(uid).get();
    const displayName = userSnapshot.get('displayName') || 'Pengguna LAMA STAR';
    const batch = db.batch();
    batch.set(memberRef, {
      uid,
      displayName,
      role: 'member',
      isMuted: false,
      handRaised: false,
      joinedAt: FieldValue.serverTimestamp(),
    });
    batch.update(roomRef, { memberCount: FieldValue.increment(1) });
    await batch.commit();
  }

  const memberSnapshot = await memberRef.get();
  return { role: memberSnapshot.get('role') || 'member' };
});

exports.leaveRoom = onCall({ region: REGION }, async (request) => {
  const uid = requireAuth(request);
  const roomId = textValue(request.data?.roomId, 'Room ID', 80);
  const roomRef = db.collection('rooms').doc(roomId);
  const memberRef = roomRef.collection('members').doc(uid);
  const memberSnapshot = await memberRef.get();
  if (!memberSnapshot.exists) return { ok: true };

  const roomSnapshot = await roomRef.get();
  if (!roomSnapshot.exists) {
    await memberRef.delete();
    return { ok: true };
  }

  const membersSnapshot = await roomRef.collection('members').get();
  const remainingMembers = membersSnapshot.docs.filter((doc) => doc.id !== uid);
  const nextHost = remainingMembers[0];
  const isOwner = roomSnapshot.get('ownerId') === uid;
  const batch = db.batch();
  batch.delete(memberRef);

  if (isOwner && nextHost) {
    batch.update(roomRef, {
      ownerId: nextHost.id,
      memberCount: remainingMembers.length,
    });
    batch.update(nextHost.ref, { role: 'host' });
  } else if (isOwner && !nextHost) {
    batch.delete(roomRef);
    batch.delete(db.collection('roomSecrets').doc(roomId));
  } else {
    batch.update(roomRef, { memberCount: remainingMembers.length });
  }

  await batch.commit();
  return { ok: true };
});

exports.getAgoraRtcToken = onCall(
  { region: REGION, secrets: [agoraAppIdSecret, agoraCertificateSecret] },
  async (request) => {
    const uid = requireAuth(request);
    const roomId = textValue(request.data?.roomId, 'Room ID', 80);
    const roomRef = db.collection('rooms').doc(roomId);
    const [roomSnapshot, memberSnapshot] = await Promise.all([
      roomRef.get(),
      roomRef.collection('members').doc(uid).get(),
    ]);

    if (!roomSnapshot.exists || !memberSnapshot.exists) {
      throw new HttpsError('permission-denied', 'Anda belum bergabung dengan room ini.');
    }

    const appId = agoraAppIdSecret.value();
    const appCertificate = agoraCertificateSecret.value();
    if (!appId || !appCertificate) {
      throw new HttpsError('failed-precondition', 'Secret Agora belum dikonfigurasi di server.');
    }

    const rtcUid = createRtcUid(uid);
    const tokenLifetimeSeconds = 60 * 60;
    const token = new AccessToken2(appId, appCertificate, null, tokenLifetimeSeconds);
    const rtcService = new ServiceRtc(roomId, String(rtcUid));
    rtcService.add_privilege(ServiceRtc.kPrivilegeJoinChannel, tokenLifetimeSeconds);
    rtcService.add_privilege(ServiceRtc.kPrivilegePublishAudioStream, tokenLifetimeSeconds);
    token.add_service(rtcService);

    const rtcToken = token.build();
    if (!rtcToken) {
      throw new HttpsError('internal', 'Token Agora gagal dibuat. Periksa App ID dan App Certificate.');
    }

    return { appId, token: rtcToken, uid: rtcUid, expiresIn: tokenLifetimeSeconds };
  },
);
